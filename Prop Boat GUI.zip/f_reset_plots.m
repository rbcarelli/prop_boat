function f_reset_plot()
    for i = 1:4
       figure(1)
       subplot(2,2,i)
       plot(0)
    end
end